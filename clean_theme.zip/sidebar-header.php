<?php theme_print_sidebar('header-widget-area'); ?>


<?php if (!theme_has_header_image()) : ?>
<div class="cleantheme-slider cleantheme-slidecontainerheader" data-width="900" data-height="260">
    <div class="cleantheme-slider-inner">
<div class="cleantheme-slide-item cleantheme-slideheader0">
<div class="cleantheme-textblock cleantheme-slideheader0-object300230953" data-left="50%">
        <div class="cleantheme-slideheader0-object300230953-text-container">
        <div class="cleantheme-slideheader0-object300230953-text"><p style="color: #532E03; font-size:29px;font-family:'Trebuchet MS', Arial, Helvetica, Sans-Serif;text-decoration:none">Think Big</p><p style="color: #3B2002; font-size:16px;font-family:'Trebuchet MS', Arial, Helvetica, Sans-Serif;font-weight:normal;font-style:normal">Time To Change</p></div>
    </div>
    
</div>
</div>
<div class="cleantheme-slide-item cleantheme-slideheader1">
<div class="cleantheme-textblock cleantheme-slideheader1-object52548185" data-left="50%">
        <div class="cleantheme-slideheader1-object52548185-text-container">
        <div class="cleantheme-slideheader1-object52548185-text"><p style="color: #562601; font-size:29px;font-family:'Trebuchet MS', Arial, Helvetica, Sans-Serif;text-decoration:none">Development</p><p style="color: #3D1B01; font-size:16px;font-family:'Trebuchet MS', Arial, Helvetica, Sans-Serif;font-weight:normal;font-style:normal">Hello and Welcome.</p></div>
    </div>
    
</div>
</div>
<div class="cleantheme-slide-item cleantheme-slideheader2">
<div class="cleantheme-textblock cleantheme-slideheader2-object11429946" data-left="50%">
        <div class="cleantheme-slideheader2-object11429946-text-container">
        <div class="cleantheme-slideheader2-object11429946-text"><p style="color: #312C26; font-size:29px;font-family:'Trebuchet MS', Arial, Helvetica, Sans-Serif;text-decoration:none">Professionalism</p><p style="color: #221F1B; font-size:16px;font-family:'Trebuchet MS', Arial, Helvetica, Sans-Serif;font-weight:normal;font-style:normal">Easy to Remember</p></div>
    </div>
    
</div>
</div>
<div class="cleantheme-slide-item cleantheme-slideheader3">

</div>

    </div>
</div>
<?php endif; ?>


<?php if (!theme_has_header_image()) : ?>
<div class="cleantheme-slidenavigator cleantheme-slidenavigatorheader" data-left="0">
<a href="#" class="cleantheme-slidenavigatoritem"></a><a href="#" class="cleantheme-slidenavigatoritem"></a><a href="#" class="cleantheme-slidenavigatoritem"></a><a href="#" class="cleantheme-slidenavigatoritem"></a>
</div>
<?php endif; ?>




    <div class="cleantheme-shapes">

            </div>




                
                    
