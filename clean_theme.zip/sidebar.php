
<?php if(theme_has_layout_part("default_sidebar")) : ?>

<?php theme_print_sidebar('primary-widget-area', '<div class="cleantheme-layout-cell cleantheme-sidebar1">', '</div>'); ?>

<?php endif; ?>
