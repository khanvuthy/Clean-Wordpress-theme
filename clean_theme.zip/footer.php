

                        </div>
                    </div>
                </div>
            </div>
    </div>
<footer class="cleantheme-footer">
  <div class="cleantheme-footer-inner"><?php get_sidebar('footer'); ?></div>
</footer>

</div>



<div id="wp-footer">
	<?php wp_footer(); ?>
	<!-- <?php printf(__('%d queries. %s seconds.', THEME_NS), get_num_queries(), timer_stop(0, 3)); ?> -->
</div>
</body>
</html>

